# -*- coding: utf-8 -*-
{
    'name': "Venda de Components Acústics",
    'summary': "Venda de components de cotxe",
    'author': "Daniel Moreno",
    'website': 'www.danielmorenoarellano.com',
    'category': "Vendes",
    'description': """
    	Mòdul per a gestionar les vendes.
    	=================================
    	Aquest mòdul permet enregistrar vendes al magatzem
    """,
    'depends': ['base'],
    'data': [
        'views/templates.xml',
    ],
    'application': True,
}