# -*- coding: utf-8 -*-

from . import venda_component