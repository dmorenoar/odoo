# -*- coding: utf-8 -*-

from odoo import models, fields

COLOR = [
	('negre', 'Negre'),
	('plata', 'Plata'),
	('gris', 'Gris'),
]

class VendaComponent(models.Model):
	_name = 'venda.component'
	_description = 'Gestió de la venda de components'
	name = fields.Char(string='Nom del component', required=True)
	marca = fields.Char(string='Marca', required=True)
	color = fields.Selection(COLOR, default='negre')
	is_offer = fields.Boolean('Té descompte?')
