# -*- coding: utf-8 -*-

from . import component_preu