# -*- coding: utf-8 -*-
{
    'name': 'Venda de Components Acústics',
    'summary': 'Venda de components de cotxe',
    'author': 'Daniel Moreno',
    'company': 'Ins Joan DAustria',
    'website': 'www.danielmorenoarellano.com',
    'category': "Vendes",
    'depends': ['base'],
    'data': [
        'views/templates.xml',
    ],
    'installable': True,
    'auto_install': False,
}